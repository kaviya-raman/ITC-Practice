package Inheritance;
class Q{
	Q(){
		System.out.println("Parent 0 arg constructor");
	}
}

public class class2 extends Q{
	class2(){
		this(10);
		System.out.println("Child 0 Arg Constructor");
	}
	class2(int a){
		super();
		System.out.println("Child 1 arg constructor");
	}
	public static void main(String [] args) {
		new class2();
	}

}
