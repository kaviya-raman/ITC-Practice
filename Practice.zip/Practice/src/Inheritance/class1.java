package Inheritance;
class A{
	int a = 10;
	int b = 20;
}
public class class1 extends A{
	int a = 200;
	int b = 300;
	void add(int a, int b) {
		System.out.println(a+b);
		System.out.println(this.a + this.b);
		System.out.println(super.a + super.b);
	}
	public static void main(String[] arg)
	{
		new class1().add(2000,3000);
	}
}
