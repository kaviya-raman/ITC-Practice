package Polymorphism;
// operator overloading
public class class2 {
	public static void main(String [] args) {
		System.out.println(10+20);
		System.out.println("kaviya"+"raman");
		System.out.println("kaviya"+20);
		System.out.println("kaviya"+20+"raman");
	}

}
