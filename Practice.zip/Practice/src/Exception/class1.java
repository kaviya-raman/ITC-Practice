package Exception;

public class class1 {
	public static void main(String [] arg) {
		System.out.println("Hi world");
		System.out.println("Hi world");
		System.out.println("10/0);
		System.out.println("Hi world");
		System.out.println("Hi world");
	}

}
