package Abstraction;
abstract class birla{
	abstract void printInfo();
}
class Employee extends birla{
	void printInfo()
	{
		String name = "Test";
		int age = 21;
		float salary = 222.2F;
		System.out.println(name);
		System.out.println(age);
		System.out.println(salary);
	}
}

public class class1 {
	public static void main(String[] arg) {
		birla s = new Employee();
		s.printInfo();
	}

}
