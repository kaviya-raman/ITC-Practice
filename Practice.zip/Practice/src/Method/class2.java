package Method;

public class class2 {
	void m1(int a, char ch) {
		System.out.println("m1 method");
		System.out.println("a");
		System.out.println("b");
	}
	static void m2(String str, double d) {
		System.out.println("m2 method");
		System.out.println(str);
		System.out.println(d);
	}
	public static void main(String[] args) {
		class2 t = new class2();
		t.m1(10,'r');
		t.m2("ram", 10.5);
	}

}
