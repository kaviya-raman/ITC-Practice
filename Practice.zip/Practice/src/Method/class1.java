package Method;

public class class1 {
	void m1() {
		System.out.println("m1 method");
	}
	static void m2() {
		System.out.println("m2 method");
	}
	public static void main(String[] args) {
		class1 t = new class1();
		t.m1();
		class1.m2();
	}

}
