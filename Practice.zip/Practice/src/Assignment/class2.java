package Assignment;
import java.util.*;
public class class2 {
    public static void main(String[] args) {
        int sqFeet = 1500;
        int pricePerSqFt = 5000;
        double basePrice = sqFeet * pricePerSqFt;
        double regTax = 0.08 * basePrice;
        double gst = 0.03 * basePrice;
        double total = basePrice + regTax + gst;
        ArrayList<String> steps = new ArrayList<>();
        steps.add("Flat Area: " + sqFeet + " Sq Ft");
        steps.add("Price per Sq Ft: ₹" + pricePerSqFt);
        steps.add("Base Price: ₹" + basePrice);
        steps.add("Registration Tax (8%): ₹" + regTax);
        steps.add("GST (3%): ₹" + gst);
        steps.add("Total Price to Pay: ₹" + total);
        System.out.println("=== Real Estate Calculation ===");
        for (String s : steps) {
            System.out.println(s);
        }
    }
}