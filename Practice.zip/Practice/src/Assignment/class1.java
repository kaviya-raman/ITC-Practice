package Assignment;
import java.util.*;
class Person {
    String name, surname, phone, email, place;
    // Constructor
    public Person(String name, String surname, String phone, String email, String place) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.email = email;
        this.place = place;
    }
}
public class class1 { // <-- changed class name to Main
    public static void main(String[] args) {
        // Create LinkedList of Person
        List<Person> list = new LinkedList<>();
        // Create Person entries using constructor
        Person p1 = new Person("Kaviya", "R", "9876543210", "bhuvana@gmail.com", "Chennai");
        Person p2 = new Person("Raghul", "S", "8765432190", "rahul@gmail.com", "Mumbai");
        Person p3 = new Person("Kayal", "K", "9123456789", "deepa@gmail.com", "Coimbatore");
        // Add to list
        list.add(p1);
        list.add(p2);
        list.add(p3);
        // Traverse and print
        System.out.println("=== Telephone Directory ===");
        for (Person p : list) {
            System.out.println(p.name + " " + p.surname + " | " + p.phone + " | " + p.email + " | " + p.place);
        }
    }
}