package ArrayDequeue;
import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;
public class class4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SortedSet<Integer> setNumbers = new TreeSet<>();
		setNumbers.addAll(Arrays.asList(2, 1, 4, 3, 6, 5, 8, 7, 0, 9));
		System.out.println("Sorted Set: " + setNumbers);
	}
}
