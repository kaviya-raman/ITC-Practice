package Satatic_blocks;

public class class1 {
	{
		System.out.println("Instance block 1");
	}
	{
		System.out.println("Instance block 2");
	}
	static {
		System.out.println("Static block 1");
	}
	static {
		System.out.println("Static block 2");
	}
	class1(){
		System.out.println("0 Arg Constructor");
	}
	class1(int a){
		System.out.println("1 Arg Constructor");
	}
;	public static void main(String[] args) {
		new class1();
		new class1(10);
	}

}
