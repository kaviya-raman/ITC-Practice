package Constructor;

public class class4 {
	int eid;
	String ename;
	int esal;
	class4(int eid, String ename, int esal){
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
	}
	void disp() {
		System.out.println("Emp ID: " +eid);
		System.out.println("Emp name: " +ename);
		System.out.println("Emp Salary: " +esal);
	}
	public static void main(String[] args) {
		class4 emp = new class4(1001, "Kaviya", 10000);
		emp.disp();
		class4 emp1 =new class4(1002, "Thamseel", 10000);
		emp1.disp();
	}

}
