package Constructor;

public class class2 {
	int eid;
	String ename;
	int esal;
	void disp() {
		System.out.println("Emp ID " +eid);
		System.out.println("Emp Name " +ename);
		System.out.println("Emp Salary " +esal);
	}
	public static void main(String[] args) {
		class2 emp = new class2();
		emp.disp();
	}

}
