package Constructor;

public class class3 {
	int eid;
    String ename;
    float esal;
    class3(){
    	eid = 001;
    	ename = "Kaviya";
    	esal = 27677;
    }
    void disp() {
		System.out.println("Emp ID " +eid);
		System.out.println("Emp Name " +ename);
		System.out.println("Emp Salary " +esal);
	}
	public static void main(String[] args) {
		class3 emp = new class3();
		emp.disp();
	}
    	
    }


