package SamplePractice;

public class Static_variable {
	static int a =100;
	static int b =200;
	public static void main(String[] args) {
		System.out.println(Static_variable.a);
		System.out.println(Static_variable.b);
		Static_variable t = new Static_variable();
		t.m1();
	}
	void m1() {
		System.out.println(Static_variable.a);
		System.out.println(Static_variable.b);
		//System.out.println(t.b);
	}

}
