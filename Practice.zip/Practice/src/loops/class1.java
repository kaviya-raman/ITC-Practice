package loops;

public class class1 {
	public static void main(String[] arg) {
		int n =1;
		switch(n++) {
		case 1:
			System.out.println("Hi team");
			break;
		case 2:
			System.out.println("Hello team");
			break;
		default:
			System.out.println("Bye team");
			break;
		}
	}

}
