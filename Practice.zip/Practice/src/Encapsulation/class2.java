package Encapsulation;

public class class2 {
	public static void main(String[] arg) {
		class1 person = new class1();
		person.setName("John");
		person.setAge(30);
		System.out.println("Name: "+person.getName());
		System.out.println("Age: "+person.getAge());
	}

}
