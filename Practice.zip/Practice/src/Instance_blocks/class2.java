package Instance_blocks;

public class class2 {
	class2(){
		System.out.println("0 arg constructor");
	}
	class2(int a){
		System.out.println("1 arg constructor");
	}
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) {
		new class2();
		new class2(10);

	}
}
