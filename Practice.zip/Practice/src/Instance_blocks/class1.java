package Instance_blocks;

public class class1 {
	class1(){
		System.out.println("0 arg constructor");
	}
	//instance block, instance block will print first and then constructor class
	{
		System.out.println("instance block");
	}
	public static void main(String[] args) {
		new class1();
		
	}

}
